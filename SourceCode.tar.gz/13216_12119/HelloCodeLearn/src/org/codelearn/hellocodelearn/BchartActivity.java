package org.codelearn.hellocodelearn;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.widget.LinearLayout;
import android.graphics.Color;
import android.view.View;


public class BchartActivity extends Activity {

	LinearLayout la;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_bchart);

	Intent intent = getIntent();
	int Value1 = intent.getIntExtra("number1",0);
	int Value2 = intent.getIntExtra("number2",0);
	int Value3 = intent.getIntExtra("number3",0);
	int Value4 = intent.getIntExtra("number4",0);
	int Value5 = intent.getIntExtra("number5",0);
	int Value6 = intent.getIntExtra("number6",0);
	int Value7 = intent.getIntExtra("number7",0);
	int Value8 = intent.getIntExtra("number8",0);
	int Value9 = intent.getIntExtra("number9",0);
	int Value10 = intent.getIntExtra("number10",0);
			
		
		
    la=(LinearLayout)findViewById(R.id.chart);	
	int color[]={1,2,3,4,5,6,7,8,9,10};
	
	int Height[]={Value1,Value2,Value3,Value4,Value5,Value6,Value7,Value8,Value9,Value10};
     
	
	for(int j=0;j<color.length;j++)
	{
		drawChart(1,color[j],Height[j]);
	}
	
	}	
	
	private void drawChart(int count,int  color,int height)
	{

		System.out.println(count+color+height);
		if(color==1)
		{
		color=Color.BLUE;
		}
		
		if(color==2)
		{
		color=Color.YELLOW;
		}
		
		if(color==3)
		{
		color=Color.GREEN;
		}

		if(color==4)
		{
		color=Color.MAGENTA;
		}
		
		if(color==5)
		{
		color=Color.RED;
		}

		if(color==6)
		{
		color=Color.BLUE;
		}

		if(color==7)
		{
		color=Color.YELLOW;
		}

		if(color==8)
		{
		color=Color.GREEN;
		}

		if(color==9)
		{
		color=Color.MAGENTA;
		}

		if(color==10)
		{
		color=Color.RED;
		}
		
		for(int k=1;k<=count;k++)
		{
			View view=new View(this);
			view.setBackgroundColor(color);
			view.setLayoutParams(new LinearLayout.LayoutParams(20,height));
			
			LinearLayout.LayoutParams params=(LinearLayout.LayoutParams)view.getLayoutParams();
		
			params.setMargins(3,0, 0, 0);
			view.setLayoutParams(params);
			//android:layout_below="@+id/btn_chart"
			 
			la.addView(view);
		}
		
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.bchart, menu);
		return true;
	}

}
	