package org.codelearn.hellocodelearn;

import android.os.Bundle;
import android.widget.Button;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.widget.TextView;
import android.content.Intent;

public class CodeLearnMainActivity extends Activity {
	
	private RadioGroup radioGroup;
	private RadioButton radioBtn1;
    private Button btn;
    private RadioButton rb1,rb2,rb4;
    private TextView textView;

	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_code_learn_main);
        
        
        radioGroup = (RadioGroup)findViewById(R.id.radioGroup1);
        rb1 = (RadioButton)findViewById(R.id.radio0); 
        rb2 = (RadioButton) findViewById(R.id.radio1);
        //rb3 = (RadioButton) findViewById(R.id.radio2); 
        rb4 = (RadioButton) findViewById(R.id.radio3);
      
        btn=(Button)findViewById(R.id.button1);
        textView=(TextView) findViewById(R.id.text);
        
              btn.setOnClickListener(new OnClickListener() {

          @Override
          public void onClick(View v)
          {
            // get selected radio button from radioGroupCricket
     
        	  rb1 = (RadioButton)findViewById(R.id.radio0); 
              rb2 = (RadioButton) findViewById(R.id.radio1);
          //    rb3 = (RadioButton) findViewById(R.id.radio2); 
              rb4 = (RadioButton) findViewById(R.id.radio3);
            
        	  int selected = radioGroup.getCheckedRadioButtonId();
        	  
            
       
            if(rb1.isChecked()) 
            {
            	Intent intent = new Intent(getApplicationContext(),PiActivity.class);
                startActivity(intent);
            }
            if(rb2.isChecked())
            {
            	Intent intent = new Intent(getApplicationContext(),LineActivity.class);
	           startActivity(intent);
            }
            if(rb4.isChecked())
            {
                  	Intent intent = new Intent(getApplicationContext(),BarActivity.class);
                  startActivity(intent);
            } 
            
            
                 } 
       });	
    }
    
        

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.code_learn_main, menu);
        return true;
    }
    
}
