package org.codelearn.hellocodelearn;

import org.achartengine.ChartFactory;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class LineActivity extends Activity {

	private String[] mMonth = new String[] {
				"Jan", "Feb" , "Mar", "Apr", "May", "Jun",
				"Jul", "Aug" , "Sep", "Oct", "Nov", "Dec"
			};
	 int val1=0,val2=0,val3=0,val4=0,val5=0,val6=0,val7=0,val8=0,val9=0,val10=0;
  	  
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_line);
		
		final EditText num1=(EditText)findViewById(R.id.editText1);
		final EditText num2=(EditText)findViewById(R.id.editText2);
		final EditText num3=(EditText)findViewById(R.id.editText3);
		final EditText num4=(EditText)findViewById(R.id.editText4);
		final EditText num5=(EditText)findViewById(R.id.editText5);
		final EditText num6=(EditText)findViewById(R.id.editText6);
		final EditText num7=(EditText)findViewById(R.id.editText7);
		final EditText num8=(EditText)findViewById(R.id.editText8);
		final EditText num9=(EditText)findViewById(R.id.editText9);
		final EditText num10=(EditText)findViewById(R.id.editText10);
		
	
	
		Button btn=(Button)findViewById(R.id.button1); 
		 btn.setOnClickListener(new OnClickListener()
        {
             public void onClick(View arg0)
             {
            	 
            	 
           	    if(num1.getText().length()==0)
        			val1=0;	
        		else
               	    val1=Integer.parseInt(num1.getText().toString());
               	
             	if(num2.getText().length()==0)
        			val2=0;	
        		else
        			val2=Integer.parseInt(num2.getText().toString());
               	
             	if(num3.getText().length()==0)
        			val3=0;	
        		else
        			val3=Integer.parseInt(num3.getText().toString());
               	
             	if(num4.getText().length()==0)
        			val4=0;	
        		else
                   	val4=Integer.parseInt(num4.getText().toString());
               
             	if(num5.getText().length()==0)
        			val5=0;	
        		else
        			val5=Integer.parseInt(num5.getText().toString());
               	
             	if(num6.getText().length()==0)
        			val6=0;	
        		else
        			val6=Integer.parseInt(num6.getText().toString());
               	
             	if(num7.getText().length()==0)
        			val7=0;	
        		else
        			val7=Integer.parseInt(num7.getText().toString());
               	
             	if(num8.getText().length()==0)
        			val8=0;	
        		else
        			val8=Integer.parseInt(num8.getText().toString());
               	
             	if(num9.getText().length()==0)
        			val9=0;	
        		else
        			val9=Integer.parseInt(num9.getText().toString());
               	
             	if(num10.getText().length()==0)
        			val10=0;	
        		else
        			val10=Integer.parseInt(num10.getText().toString());
             	
             	
            	int data[]={val1,val2,val3,val4,val5,val6,val7,val8,val9,val10};
            	 int[] income = {100,110,120,130,140,150,160,170,180,190};
                 
        	    // Creating an  XYSeries for Income
                XYSeries plotseries = new XYSeries("demoplot");
                XYSeries incomeSeries = new XYSeries("Income");
                
                for(int i=0;i<data.length;i++){
                    plotseries.add(i+1,data[i]);
                    incomeSeries.add(i+1, income[i]);
                    
                  }
         
                // Creating a dataset to hold each series
                XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();
                // Adding Income Series to the dataset
                dataset.addSeries(plotseries);
                dataset.addSeries(incomeSeries);
                
                // Adding Expense Series to dataset
                //dataset.addSeries(expenseSeries);
         
                // Creating XYSeriesRenderer to customize incomeSeries
                XYSeriesRenderer demorender = new XYSeriesRenderer();
                demorender.setColor(Color.WHITE);
                demorender.setPointStyle(PointStyle.CIRCLE);
                demorender.setFillPoints(true);
                demorender.setLineWidth(2);
                demorender.setDisplayChartValues(true);
                
                XYSeriesRenderer incomeRenderer = new XYSeriesRenderer();
                incomeRenderer.setColor(Color.WHITE);
                incomeRenderer.setPointStyle(PointStyle.CIRCLE);
                incomeRenderer.setFillPoints(true);
                incomeRenderer.setLineWidth(2);
                incomeRenderer.setDisplayChartValues(true);
                // Creating a XYMultipleSeriesRenderer to customize the whole chart
                XYMultipleSeriesRenderer multiRenderer = new XYMultipleSeriesRenderer();
                multiRenderer.setXLabels(0);
                multiRenderer.setChartTitle("Demo charts and triyals");
                multiRenderer.setXTitle("Input values");
                multiRenderer.setYTitle("scale in 100");
                multiRenderer.setZoomButtonsVisible(true);
                
                for(int i=0;i<data.length;i++){
                    multiRenderer.addXTextLabel(i, mMonth[i]);
                }
         
                // Adding incomeRenderer and expenseRenderer to multipleRenderer
                // Note: The order of adding dataseries to dataset and renderers to multipleRenderer
                // should be same
                multiRenderer.addSeriesRenderer(demorender);
                multiRenderer.addSeriesRenderer(incomeRenderer);
                
                // Creating an intent to plot line chart using dataset and multipleRenderer
                Intent intent2 = ChartFactory.getLineChartIntent(getBaseContext(), dataset, multiRenderer);
         
                // Start Activity
                startActivity(intent2);
            }
             
             
            });
        
	}
	
	 
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.line, menu);
		return true;
	}

}
