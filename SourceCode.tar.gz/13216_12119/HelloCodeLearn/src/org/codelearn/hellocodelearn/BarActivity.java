package org.codelearn.hellocodelearn;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

import org.achartengine.model.XYSeries;

import android.graphics.Color;

public class BarActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_bar);
		
		final EditText num1=(EditText)findViewById(R.id.editText1);
		final EditText num2=(EditText)findViewById(R.id.editText2);
		final EditText num3=(EditText)findViewById(R.id.editText3);
		final EditText num4=(EditText)findViewById(R.id.editText4);
		final EditText num5=(EditText)findViewById(R.id.editText5);
		final EditText num6=(EditText)findViewById(R.id.editText6);
		final EditText num7=(EditText)findViewById(R.id.editText7);
		final EditText num8=(EditText)findViewById(R.id.editText8);
		final EditText num9=(EditText)findViewById(R.id.editText9);
		final EditText num10=(EditText)findViewById(R.id.editText10);
		
	//	if(num1.getText().length()==0)
		//	num1=;	
		
		
		 Button btn=(Button)findViewById(R.id.button1);
		
		 
		 btn.setOnClickListener(new OnClickListener()
        {
             public void onClick(View arg0)
             {
           	  int val1=0,val2=0,val3=0,val4=0,val5=0,val6=0,val7=0,val8=0,val9=0,val10=0;
            	 
           	  Intent intent = new Intent(BarActivity.this,BchartActivity.class);
           	 
           	if(num1.getText().length()==0)
    			val1=0;	
    		else
           	    val1=Integer.parseInt(num1.getText().toString());
           	
         	if(num2.getText().length()==0)
    			val2=0;	
    		else
    			val2=Integer.parseInt(num2.getText().toString());
           	
         	if(num3.getText().length()==0)
    			val3=0;	
    		else
    			val3=Integer.parseInt(num3.getText().toString());
           	
         	if(num4.getText().length()==0)
    			val4=0;	
    		else
               	val4=Integer.parseInt(num4.getText().toString());
           
         	if(num5.getText().length()==0)
    			val5=0;	
    		else
    			val5=Integer.parseInt(num5.getText().toString());
           	
         	if(num6.getText().length()==0)
    			val6=0;	
    		else
    			val6=Integer.parseInt(num6.getText().toString());
           	
         	if(num7.getText().length()==0)
    			val7=0;	
    		else
    			val7=Integer.parseInt(num7.getText().toString());
           	
         	if(num8.getText().length()==0)
    			val8=0;	
    		else
    			val8=Integer.parseInt(num8.getText().toString());
           	
         	if(num9.getText().length()==0)
    			val9=0;	
    		else
    			val9=Integer.parseInt(num9.getText().toString());
           	
         	if(num10.getText().length()==0)
    			val10=0;	
    		else
    			val10=Integer.parseInt(num10.getText().toString());
         	  
           	intent.putExtra("number1",val1);
           	intent.putExtra("number2",val2);
           	intent.putExtra("number3",val3);
           	intent.putExtra("number4",val4);
           	intent.putExtra("number5",val5);
           	intent.putExtra("number6",val6);
           	intent.putExtra("number7",val7);
           	intent.putExtra("number8",val8);
           	intent.putExtra("number9",val9);
           	intent.putExtra("number10",val10);
        	  
           	
           	
           	  startActivity(intent);
             }
        });
        //btn.setOnClickListener(clickListener);
        
    }
 
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.bar, menu);
        return true;
    }
}