package org.codelearn.hellocodelearn;

import java.text.DecimalFormat;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.renderer.DefaultRenderer;
import org.achartengine.model.CategorySeries;
import org.achartengine.model.SeriesSelection;
import org.achartengine.renderer.SimpleSeriesRenderer;

import android.R.bool;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class PinputActivity extends Activity {

	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(new MyView(this));
	
		
		
		
	}
	
	  public class MyView extends View {



			public MyView(Context context) {

				super(context);

				// TODO Auto-generated constructor stub

			}



			@Override

			protected void onDraw(Canvas canvas) {

				// TODO Auto-generated method stub

				super.onDraw(canvas);



				

				float width = (float)getWidth();

				float height = (float)getHeight();

				float radius;

				

				if (width > height){

					radius = height/4;

				}else{

					radius = width/4;

				}

				

				Path path = new Path();

				path.addCircle(width/2, 

						height/2, radius, 

						Path.Direction.CW);

				

				Paint paint = new Paint();

				paint.setColor(Color.WHITE);

				paint.setStrokeWidth(5);	



				paint.setStyle(Paint.Style.FILL);

				float center_x, center_y;

				center_x = width/2;

				center_y = height/4;

				final RectF oval = new RectF();

				oval.set(center_x - radius,center_y - radius,center_x + radius,center_y + radius);
				
				Intent intent = getIntent();
				
				int Value1 = intent.getIntExtra("number1",0);
				int Value2 = intent.getIntExtra("number2",0);
				int Value3 = intent.getIntExtra("number3",0);
				int Value4 = intent.getIntExtra("number4",0);
				int Value5 = intent.getIntExtra("number5",0);
				int Value6 = intent.getIntExtra("number6",0);
				int Value7 = intent.getIntExtra("number7",0);
				int Value8 = intent.getIntExtra("number8",0);
				int Value9 = intent.getIntExtra("number9",0);
				int Value10 = intent.getIntExtra("number10",0);
					
			    int color[]={1,2,3,4,5,6,7,8,9,10};
				
				int data[]={Value1,Value2,Value3,Value4,Value5,Value6,Value7,Value8,Value9,Value10};
			    
				float total = 0;
				
				for (int i = 0; i < data.length; i++) 
				{
				    total += data[i];
				}
				
				float startAngle = 0, sweepAngle;
				
				for(int i=0;i<data.length; i++)
				{
					if(color[i]==1)
					{
					color[i]=Color.BLUE;
					}
					
					if(color[i]==2)
					{
					color[i]=Color.YELLOW;
					}
					
					if(color[i]==3)
					{
					color[i]=Color.GREEN;
					}

					if(color[i]==4)
					{
					color[i]=Color.MAGENTA;
					}
					
					if(color[i]==5)
					{
					color[i]=Color.RED;
					}

					if(color[i]==6)
					{
					color[i]=Color.BLUE;
					}

					if(color[i]==7)
					{
					color[i]=Color.YELLOW;
					}

					if(color[i]==8)
					{
					color[i]=Color.GREEN;
					}

					if(color[i]==9)
					{
					color[i]=Color.MAGENTA;
					}

					if(color[i]==10)
					{
					color[i]=Color.RED;
					}
					paint.setColor(color[i]);
				
					sweepAngle = data[i] * (360f / total);
				
					canvas.drawArc(oval,startAngle,sweepAngle, true, paint);
					 startAngle += sweepAngle;
				}
				
				

			}



		}
			

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.pinput, menu);
		return true;
	}

}
